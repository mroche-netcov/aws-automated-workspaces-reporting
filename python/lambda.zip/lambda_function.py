import boto3
import csv
import io
import os
import smtplib
import ssl
from datetime import datetime, timedelta
from email.message import EmailMessage
from ldap3 import Server, Connection, ALL, NTLM

def lambda_handler(event, context):
    region = event.get('region', 'us-east-1')
    inactivity_days = int(event.get('inactivity_days', 60))
    s3_bucket = event['s3_bucket']
    s3_key = event.get('s3_key', 'workspacesreport.csv')
    email_recipients = event.get('email_recipients', [])

    # Environment variables for LDAP and SMTP
    ad_host = os.environ['AD_HOST']
    ad_user = os.environ['AD_USERNAME']
    ad_pass = os.environ['AD_PASSWORD']
    base_dn = 'DC=sila,DC=local'

    smtp_server = os.environ['SMTP_SERVER']
    smtp_port = int(os.environ.get('SMTP_PORT', 587))
    smtp_user = os.environ['SMTP_USER']
    smtp_pass = os.environ['SMTP_PASS']
    smtp_from = os.environ['SMTP_FROM']

    start_time = datetime.utcnow() - timedelta(days=inactivity_days)
    end_time = datetime.utcnow()
    period = 86400

    # AWS Clients
    workspaces_client = boto3.client('workspaces', region_name=region)
    cloudwatch_client = boto3.client('cloudwatch', region_name=region)
    ec2_client = boto3.client('ec2', region_name=region)

    # LDAP Connection
    server = Server(ad_host, get_info=ALL)
    conn = Connection(server, user=ad_user, password=ad_pass, authentication=NTLM, auto_bind=True)

    response = workspaces_client.describe_workspaces()
    workspaces = response['Workspaces']
    report_rows = []

    for ws in workspaces:
        try:
            workspace_id = ws['WorkspaceId']
            user_name = ws.get('UserName', '')
            computer_name = ws.get('ComputerName', '')
            subnet_id = ws.get('SubnetId', '')

            # CloudWatch Metric
            metrics = cloudwatch_client.get_metric_statistics(
                Namespace='AWS/WorkSpaces',
                MetricName='ConnectionSuccess',
                Dimensions=[{'Name': 'WorkspaceId', 'Value': workspace_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=period,
                Statistics=['Maximum']
            )
            datapoints = metrics.get('Datapoints', [])
            is_inactive = not any(dp['Maximum'] >= 1 for dp in datapoints)

            # Subnet Info
            subnet_info = ec2_client.describe_subnets(SubnetIds=[subnet_id])
            subnet = subnet_info['Subnets'][0]
            subnet_name = ''
            for tag in subnet.get('Tags', []):
                if tag['Key'] == 'Name':
                    subnet_name = tag['Value']

            # LDAP User Info
            conn.search(base_dn, f'(sAMAccountName={user_name})', attributes=['displayName','department','mail','mobile','manager','userAccountControl'])
            user_info = conn.entries[0] if conn.entries else None
            ad_full_name = user_info.displayName.value if user_info else ''
            ad_department = user_info.department.value if user_info else ''
            ad_email = user_info.mail.value if user_info else ''
            ad_mobile = user_info.mobile.value if user_info else ''
            ad_enabled = 'Disabled' if (user_info.userAccountControl.value & 2) else 'Enabled' if user_info else ''
            ad_manager = ''
            if user_info and user_info.manager.value:
                conn.search(base_dn, f'(distinguishedName={user_info.manager.value})', attributes=['displayName'])
                ad_manager = conn.entries[0].displayName.value if conn.entries else ''

            # LDAP Computer Info
            conn.search(base_dn, f'(cn={computer_name})', attributes=['whenCreated','operatingSystem'])
            computer_info = conn.entries[0] if conn.entries else None
            ad_computer_created = computer_info.whenCreated.value.isoformat() if computer_info else ''
            ad_computer_os = computer_info.operatingSystem.value if computer_info else ''

            # Add row
            row = {
                'UserName': user_name,
                'ADUserFullName': ad_full_name,
                'ComputerName': computer_name,
                'ADComputerCreated': ad_computer_created,
                'ADComputerOperatingSystem': ad_computer_os,
                'WorkSpaceId': workspace_id,
                'WorkSpaceUnusedForDefinedPeriod': is_inactive,
                'SubnetId': subnet_id,
                'SubnetLabel': subnet_name,
                'ADUserDepartment': ad_department,
                'ADUserEnabled': ad_enabled,
                'ADUserEmailAddress': ad_email,
                'ADUserManager': ad_manager,
                'ADUserMobilePhone': ad_mobile,
                'Region': region
            }
            report_rows.append(row)
        except Exception as e:
            print(f'Error processing workspace {ws.get("WorkspaceId")}: {e}')
            continue

    # Write to CSV
    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=report_rows[0].keys())
    writer.writeheader()
    writer.writerows(report_rows)

    # Upload to S3
    s3 = boto3.client('s3')
    s3.put_object(Bucket=s3_bucket, Key=s3_key, Body=csv_buffer.getvalue())

    # Email the report
    msg = EmailMessage()
    msg['Subject'] = 'Monthly WorkSpaces Usage Report'
    msg['From'] = smtp_from
    msg['To'] = ', '.join(email_recipients)
    msg.set_content('Attached is the latest Monthly WorkSpaces Usage Report.')

    msg.add_attachment(csv_buffer.getvalue(), subtype='csv', filename='workspacesreport.csv')

    context = ssl.create_default_context()
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls(context=context)
        server.login(smtp_user, smtp_pass)
        server.send_message(msg)

    return {
        'statusCode': 200,
        'body': f'Report written to s3://{s3_bucket}/{s3_key} and emailed to recipients.',
        'workspace_count': len(report_rows)
    }
